﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPerfect
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radLaura = New System.Windows.Forms.RadioButton()
        Me.radSue = New System.Windows.Forms.RadioButton()
        Me.radRon = New System.Windows.Forms.RadioButton()
        Me.radPat = New System.Windows.Forms.RadioButton()
        Me.radJane = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.radSenior = New System.Windows.Forms.RadioButton()
        Me.radStudent = New System.Windows.Forms.RadioButton()
        Me.radChild = New System.Windows.Forms.RadioButton()
        Me.radAdult = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.chkExtensions = New System.Windows.Forms.CheckBox()
        Me.chkHighligthts = New System.Windows.Forms.CheckBox()
        Me.chkColor = New System.Windows.Forms.CheckBox()
        Me.chkCut = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtClientVisits = New System.Windows.Forms.TextBox()
        Me.lblClientVisits = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.lblTotalPrice = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radLaura)
        Me.GroupBox1.Controls.Add(Me.radSue)
        Me.GroupBox1.Controls.Add(Me.radRon)
        Me.GroupBox1.Controls.Add(Me.radPat)
        Me.GroupBox1.Controls.Add(Me.radJane)
        Me.GroupBox1.Location = New System.Drawing.Point(36, 27)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 131)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Hairdresser"
        '
        'radLaura
        '
        Me.radLaura.AutoSize = True
        Me.radLaura.Location = New System.Drawing.Point(6, 102)
        Me.radLaura.Name = "radLaura"
        Me.radLaura.Size = New System.Drawing.Size(101, 16)
        Me.radLaura.TabIndex = 4
        Me.radLaura.TabStop = True
        Me.radLaura.Text = "Laura Renkins"
        Me.radLaura.UseVisualStyleBackColor = True
        '
        'radSue
        '
        Me.radSue.AutoSize = True
        Me.radSue.Location = New System.Drawing.Point(6, 81)
        Me.radSue.Name = "radSue"
        Me.radSue.Size = New System.Drawing.Size(83, 16)
        Me.radSue.TabIndex = 3
        Me.radSue.TabStop = True
        Me.radSue.Text = "Sue Pallon"
        Me.radSue.UseVisualStyleBackColor = True
        '
        'radRon
        '
        Me.radRon.AutoSize = True
        Me.radRon.Location = New System.Drawing.Point(6, 60)
        Me.radRon.Name = "radRon"
        Me.radRon.Size = New System.Drawing.Size(95, 16)
        Me.radRon.TabIndex = 2
        Me.radRon.TabStop = True
        Me.radRon.Text = "Ron Chambers"
        Me.radRon.UseVisualStyleBackColor = True
        '
        'radPat
        '
        Me.radPat.AutoSize = True
        Me.radPat.Location = New System.Drawing.Point(6, 39)
        Me.radPat.Name = "radPat"
        Me.radPat.Size = New System.Drawing.Size(89, 16)
        Me.radPat.TabIndex = 1
        Me.radPat.TabStop = True
        Me.radPat.Text = "Pat Johnson"
        Me.radPat.UseVisualStyleBackColor = True
        '
        'radJane
        '
        Me.radJane.AutoSize = True
        Me.radJane.Location = New System.Drawing.Point(6, 18)
        Me.radJane.Name = "radJane"
        Me.radJane.Size = New System.Drawing.Size(89, 16)
        Me.radJane.TabIndex = 0
        Me.radJane.TabStop = True
        Me.radJane.Text = "Jane Samley"
        Me.radJane.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.radSenior)
        Me.GroupBox2.Controls.Add(Me.radStudent)
        Me.GroupBox2.Controls.Add(Me.radChild)
        Me.GroupBox2.Controls.Add(Me.radAdult)
        Me.GroupBox2.Location = New System.Drawing.Point(36, 179)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(200, 114)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Cilent Type"
        '
        'radSenior
        '
        Me.radSenior.AutoSize = True
        Me.radSenior.Location = New System.Drawing.Point(6, 81)
        Me.radSenior.Name = "radSenior"
        Me.radSenior.Size = New System.Drawing.Size(119, 16)
        Me.radSenior.TabIndex = 3
        Me.radSenior.TabStop = True
        Me.radSenior.Text = "Senior (over 65)"
        Me.radSenior.UseVisualStyleBackColor = True
        '
        'radStudent
        '
        Me.radStudent.AutoSize = True
        Me.radStudent.Location = New System.Drawing.Point(6, 60)
        Me.radStudent.Name = "radStudent"
        Me.radStudent.Size = New System.Drawing.Size(65, 16)
        Me.radStudent.TabIndex = 2
        Me.radStudent.TabStop = True
        Me.radStudent.Text = "Student"
        Me.radStudent.UseVisualStyleBackColor = True
        '
        'radChild
        '
        Me.radChild.AutoSize = True
        Me.radChild.Location = New System.Drawing.Point(6, 39)
        Me.radChild.Name = "radChild"
        Me.radChild.Size = New System.Drawing.Size(137, 16)
        Me.radChild.TabIndex = 1
        Me.radChild.TabStop = True
        Me.radChild.Text = "Child (12and under)"
        Me.radChild.UseVisualStyleBackColor = True
        '
        'radAdult
        '
        Me.radAdult.AutoSize = True
        Me.radAdult.Location = New System.Drawing.Point(6, 18)
        Me.radAdult.Name = "radAdult"
        Me.radAdult.Size = New System.Drawing.Size(107, 16)
        Me.radAdult.TabIndex = 0
        Me.radAdult.TabStop = True
        Me.radAdult.Text = "Standard Adult"
        Me.radAdult.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.chkExtensions)
        Me.GroupBox3.Controls.Add(Me.chkHighligthts)
        Me.GroupBox3.Controls.Add(Me.chkColor)
        Me.GroupBox3.Controls.Add(Me.chkCut)
        Me.GroupBox3.Location = New System.Drawing.Point(295, 27)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(200, 131)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Services"
        '
        'chkExtensions
        '
        Me.chkExtensions.AutoSize = True
        Me.chkExtensions.Location = New System.Drawing.Point(15, 110)
        Me.chkExtensions.Name = "chkExtensions"
        Me.chkExtensions.Size = New System.Drawing.Size(84, 16)
        Me.chkExtensions.TabIndex = 3
        Me.chkExtensions.Text = "Extensions"
        Me.chkExtensions.UseVisualStyleBackColor = True
        '
        'chkHighligthts
        '
        Me.chkHighligthts.AutoSize = True
        Me.chkHighligthts.Location = New System.Drawing.Point(15, 81)
        Me.chkHighligthts.Name = "chkHighligthts"
        Me.chkHighligthts.Size = New System.Drawing.Size(84, 16)
        Me.chkHighligthts.TabIndex = 2
        Me.chkHighligthts.Text = "&Highlights"
        Me.chkHighligthts.UseVisualStyleBackColor = True
        '
        'chkColor
        '
        Me.chkColor.AutoSize = True
        Me.chkColor.Location = New System.Drawing.Point(15, 49)
        Me.chkColor.Name = "chkColor"
        Me.chkColor.Size = New System.Drawing.Size(60, 16)
        Me.chkColor.TabIndex = 1
        Me.chkColor.Text = "C&olour"
        Me.chkColor.UseVisualStyleBackColor = True
        '
        'chkCut
        '
        Me.chkCut.AutoSize = True
        Me.chkCut.Location = New System.Drawing.Point(15, 18)
        Me.chkCut.Name = "chkCut"
        Me.chkCut.Size = New System.Drawing.Size(42, 16)
        Me.chkCut.TabIndex = 0
        Me.chkCut.Text = "&Cut"
        Me.chkCut.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtClientVisits)
        Me.GroupBox4.Controls.Add(Me.lblClientVisits)
        Me.GroupBox4.Location = New System.Drawing.Point(295, 179)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(200, 92)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Client Visits"
        '
        'txtClientVisits
        '
        Me.txtClientVisits.Location = New System.Drawing.Point(15, 60)
        Me.txtClientVisits.Name = "txtClientVisits"
        Me.txtClientVisits.Size = New System.Drawing.Size(100, 21)
        Me.txtClientVisits.TabIndex = 1
        '
        'lblClientVisits
        '
        Me.lblClientVisits.AutoSize = True
        Me.lblClientVisits.Location = New System.Drawing.Point(12, 29)
        Me.lblClientVisits.Name = "lblClientVisits"
        Me.lblClientVisits.Size = New System.Drawing.Size(107, 24)
        Me.lblClientVisits.TabIndex = 0
        Me.lblClientVisits.Text = "Enter the Number " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "of Client Visits:"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.lblTotal)
        Me.GroupBox5.Controls.Add(Me.lblTotalPrice)
        Me.GroupBox5.Location = New System.Drawing.Point(36, 299)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(384, 55)
        Me.GroupBox5.TabIndex = 8
        Me.GroupBox5.TabStop = False
        '
        'lblTotal
        '
        Me.lblTotal.Location = New System.Drawing.Point(211, 25)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(71, 18)
        Me.lblTotal.TabIndex = 3
        '
        'lblTotalPrice
        '
        Me.lblTotalPrice.AutoSize = True
        Me.lblTotalPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalPrice.Location = New System.Drawing.Point(17, 25)
        Me.lblTotalPrice.Name = "lblTotalPrice"
        Me.lblTotalPrice.Size = New System.Drawing.Size(58, 13)
        Me.lblTotalPrice.TabIndex = 2
        Me.lblTotalPrice.Text = "Total Price"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(50, 374)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 21)
        Me.btnCalculate.TabIndex = 9
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(193, 374)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 21)
        Me.btnClear.TabIndex = 10
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(319, 374)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 21)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmPerfect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(590, 418)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmPerfect"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text = "Perfect Cut Hair Salon"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents radRon As System.Windows.Forms.RadioButton
    Friend WithEvents radPat As System.Windows.Forms.RadioButton
    Friend WithEvents radJane As System.Windows.Forms.RadioButton
    Friend WithEvents radSue As System.Windows.Forms.RadioButton
    Friend WithEvents radLaura As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents radSenior As System.Windows.Forms.RadioButton
    Friend WithEvents radStudent As System.Windows.Forms.RadioButton
    Friend WithEvents radChild As System.Windows.Forms.RadioButton
    Friend WithEvents radAdult As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents chkExtensions As System.Windows.Forms.CheckBox
    Friend WithEvents chkHighligthts As System.Windows.Forms.CheckBox
    Friend WithEvents chkColor As System.Windows.Forms.CheckBox
    Friend WithEvents chkCut As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtClientVisits As System.Windows.Forms.TextBox
    Friend WithEvents lblClientVisits As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents lblTotalPrice As System.Windows.Forms.Label
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblTotal As System.Windows.Forms.Label

End Class
