﻿Public Class frmPerfect
    'Statement of Author ship: I, Lei Feng, 000355541 certify that this material is my original work. 
    '                          No other person's work has been used without due acknowledgement.
    '
    'Program description: 
    '                1.	Select one Hairdresser:  each hairdresser has a different base rate
    '                   Base rates are:  Jane is $30, Pat is $45, Ron is $40, Sue is $50, and Laurie is $55
    '                2.	Select one or more Services 
    '                   Service rates are: Cut $30, Colour $40, Highlights $50, Extensions $200
    '                3.	Select one Client Type: each client falls under one of four categories which determines if that client will receive a discount and at what rate
    '                   Rates are:  Standard Adult is 0%,    Child is 10%,    Student is 5%,    Senior is 15%
    '                4.	Enter number of Visits:  each client may receive an additional discount based on the number of visits they have had with a hairdresser
    '                   Visit rates are:  1 to 3 is 0%,    4 to 8 is 5%,    9 to 13 is 10%,    14 and up is 15%
    '                5.	Click on Calculate: will calculate and display  total price

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' Declare local variables.
        Dim decBaseRate As Decimal   '  Base hairdresser rate
        Dim decServiceFee As Decimal   '  Base services fee
        Dim decTotalPrice As Decimal  ' Total price
        Dim decVisits As Decimal     ' Number of visits
        Dim decVisitsDiscount As Decimal  ' Discount based on the number of visits.
        Dim decClientTypeDiscount As Decimal  ' Discount based on the number of visits.
        Dim strErrorMessage As String = ""   ' Error Message
        Dim blnPass As Boolean = True       ' pass

        ' Constants for base Rate
        Const decJANE_RATE As Decimal = 30D
        Const decPAT_RATE As Decimal = 45D
        Const decRON_RATE As Decimal = 40D
        Const decSUE_RATE As Decimal = 50D
        Const decLAURA_RATE As Decimal = 55D

        ' Constants for Services  fees
        Const decCUT_FEE As Decimal = 30D
        Const decCOLOUR_FEE As Decimal = 40D
        Const decHIGHLIGHTS_FEE As Decimal = 50D
        Const decEXTENSIONS_FEE As Decimal = 200D

        ' Check if the services is selected
        If chkCut.Checked = False And chkColor.Checked = False And chkHighligthts.Checked = False And chkExtensions.Checked = False Then
            ' Error: None service is selected.
            strErrorMessage += "Must select at least one service." & vbCrLf
            blnPass = False
        End If

        ' Check if the client type is selected
        If radAdult.Checked = False And radChild.Checked = False And radStudent.Checked = False And radSenior.Checked = False Then
            ' Error: None client type is selected.
            strErrorMessage += "Must select at one client type." & vbCrLf
            blnPass = False
        End If

        ' Get the number of Visits.
        Try
            decVisits = CDec(txtClientVisits.Text)
            If decVisits Mod 1 <> 0 Then
                ' Error: value entered for Visits is not an integer.
                strErrorMessage += "Visits must be an integer." & vbCrLf
                blnPass = False
            End If

            If decVisits <= 0 Then
                ' Error: value entered for Visits is less than zero.
                strErrorMessage += "Visits must be larger than 0."
                blnPass = False
            End If
        Catch ex As Exception
            strErrorMessage += "Visits must be an integer."
            blnPass = False
        End Try


        If blnPass = True Then
            ' Determine the base hairdresser rate.
            If radJane.Checked = True Then
                decBaseRate = decJANE_RATE
            ElseIf radPat.Checked = True Then
                decBaseRate = decPAT_RATE
            ElseIf radRon.Checked = True Then
                decBaseRate = decRON_RATE
            ElseIf radSue.Checked = True Then
                decBaseRate = decSUE_RATE
            ElseIf radLaura.Checked = True Then
                decBaseRate = decLAURA_RATE
            End If

            ' Determine the services rate.
            If chkCut.Checked = True Then
                decServiceFee += decCUT_FEE
            End If

            If chkColor.Checked = True Then
                decServiceFee += decCOLOUR_FEE
            End If

            If chkHighligthts.Checked = True Then
                decServiceFee += decHIGHLIGHTS_FEE
            End If

            If chkExtensions.Checked = True Then
                decServiceFee += decEXTENSIONS_FEE
            End If

            '  Determine the discount based on the Client Type.
            If radAdult.Checked = True Then
                decClientTypeDiscount = 1 - 0
            ElseIf radChild.Checked = True Then
                decClientTypeDiscount = 1 - 0.1
            ElseIf radStudent.Checked = True Then
                decClientTypeDiscount = 1 - 0.05
            ElseIf radSenior.Checked = True Then
                decClientTypeDiscount = 1 - 0.15
            End If

            ' Determine the discount based on the number of visits.
            If decVisits >= 1 And decVisits <= 3 Then
                decVisitsDiscount = 1 - 0
            ElseIf decVisits >= 4 And decVisits <= 8 Then
                decVisitsDiscount = 1 - 0.05
            ElseIf decVisits >= 9 And decVisits <= 13 Then
                decVisitsDiscount = 1 - 0.1
            ElseIf decVisits >= 14 Then
                decVisitsDiscount = 1 - 0.15
            End If

            ' Calculate the total fee.
            decTotalPrice = (decBaseRate + decServiceFee) * decClientTypeDiscount * decVisitsDiscount

            ' Display the fees.
            lblTotal.Text = decTotalPrice.ToString("c")
        End If

        If strErrorMessage <> "" Then
            MessageBox.Show(strErrorMessage)
        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Close the form.
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        ' Reset the Adult radio button.
        radJane.Checked = True
        radAdult.Checked = True

        ' Clear the check boxes.
        chkCut.Checked = False
        chkColor.Checked = False
        chkHighligthts.Checked = False
        chkExtensions.Checked = False

        ' Clear the fee labels.
        lblTotal.Text = String.Empty

        ' Clear the number of months.
        txtClientVisits.Clear()

        ' Give txtMonths the focus.
        txtClientVisits.Focus()

    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Calculate when user hits enter
        Me.AcceptButton = btnCalculate
    End Sub

    Private Sub radAdult_CheckedChanged(sender As Object, e As EventArgs) Handles radAdult.CheckedChanged

    End Sub

    Private Sub chkCut_CheckedChanged(sender As Object, e As EventArgs) Handles chkCut.CheckedChanged

    End Sub
End Class
