﻿
'Statement of Author ship: I,Lei Feng, 000355541
'                          certify that this material is my original work. 
'                          No other person's work has been used without due acknowledgement.
'
Public Class frmHairdresser
    Private Sub btnAddHairdresser_Click(sender As Object, e As EventArgs) Handles btnAddHairdresser.Click
        ' check if there are selections, then add it to the list
        If lstHairdresser.SelectedIndex <> -1 Then
            frmMain.lstHairdresserAndServices.Items.Add(lstHairdresser.SelectedItem)
            AddHairdresserPrice()
            Me.Close()
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub frmHairdresser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Load hairdresser values by module1
        LoadTypeValues(Module1.strHairdresser, lstHairdresser)
    End Sub

    Private Sub AddHairdresserPrice()

        ' select statement to add each hairdresser base prices by index 
        Select Case lstHairdresser.SelectedIndex
            Case 0
                frmMain.lstPrice.Items.Add(Module1.dblHairdresserBasePrices(0).ToString("c"))
            Case 1
                frmMain.lstPrice.Items.Add(Module1.dblHairdresserBasePrices(1).ToString("c"))
            Case 2
                frmMain.lstPrice.Items.Add(Module1.dblHairdresserBasePrices(2).ToString("c"))
            Case 3
                frmMain.lstPrice.Items.Add(Module1.dblHairdresserBasePrices(3).ToString("c"))
            Case 4
                frmMain.lstPrice.Items.Add(Module1.dblHairdresserBasePrices(4).ToString("c"))
        End Select
    End Sub

End Class