﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDiscount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtNumberofVisits = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lstSelectClientType = New System.Windows.Forms.ListBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblVisitDiscountAmount = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblClientTypeDiscountAmount = New System.Windows.Forms.Label()
        Me.btnCalculateVisitDiscount = New System.Windows.Forms.Button()
        Me.btnCalculateTypeDiscount = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtNumberofVisits
        '
        Me.txtNumberofVisits.Location = New System.Drawing.Point(25, 37)
        Me.txtNumberofVisits.Multiline = True
        Me.txtNumberofVisits.Name = "txtNumberofVisits"
        Me.txtNumberofVisits.Size = New System.Drawing.Size(135, 40)
        Me.txtNumberofVisits.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(137, 12)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Enter Number of Visits"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 114)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(113, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Select Client Type"
        '
        'lstSelectClientType
        '
        Me.lstSelectClientType.FormattingEnabled = True
        Me.lstSelectClientType.ItemHeight = 12
        Me.lstSelectClientType.Location = New System.Drawing.Point(27, 145)
        Me.lstSelectClientType.Name = "lstSelectClientType"
        Me.lstSelectClientType.Size = New System.Drawing.Size(206, 124)
        Me.lstSelectClientType.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(277, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(131, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Visit Discount Amount"
        '
        'lblVisitDiscountAmount
        '
        Me.lblVisitDiscountAmount.AutoSize = True
        Me.lblVisitDiscountAmount.Location = New System.Drawing.Point(277, 40)
        Me.lblVisitDiscountAmount.Name = "lblVisitDiscountAmount"
        Me.lblVisitDiscountAmount.Size = New System.Drawing.Size(41, 12)
        Me.lblVisitDiscountAmount.TabIndex = 5
        Me.lblVisitDiscountAmount.Text = "Label4"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(277, 114)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(167, 12)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Client Type Discount Amount"
        '
        'lblClientTypeDiscountAmount
        '
        Me.lblClientTypeDiscountAmount.AutoSize = True
        Me.lblClientTypeDiscountAmount.Location = New System.Drawing.Point(277, 145)
        Me.lblClientTypeDiscountAmount.Name = "lblClientTypeDiscountAmount"
        Me.lblClientTypeDiscountAmount.Size = New System.Drawing.Size(41, 12)
        Me.lblClientTypeDiscountAmount.TabIndex = 7
        Me.lblClientTypeDiscountAmount.Text = "Label6"
        '
        'btnCalculateVisitDiscount
        '
        Me.btnCalculateVisitDiscount.Location = New System.Drawing.Point(27, 293)
        Me.btnCalculateVisitDiscount.Name = "btnCalculateVisitDiscount"
        Me.btnCalculateVisitDiscount.Size = New System.Drawing.Size(111, 42)
        Me.btnCalculateVisitDiscount.TabIndex = 8
        Me.btnCalculateVisitDiscount.Text = "Calculate Visit Discount"
        Me.btnCalculateVisitDiscount.UseVisualStyleBackColor = True
        '
        'btnCalculateTypeDiscount
        '
        Me.btnCalculateTypeDiscount.Location = New System.Drawing.Point(153, 293)
        Me.btnCalculateTypeDiscount.Name = "btnCalculateTypeDiscount"
        Me.btnCalculateTypeDiscount.Size = New System.Drawing.Size(100, 42)
        Me.btnCalculateTypeDiscount.TabIndex = 9
        Me.btnCalculateTypeDiscount.Text = "Calculate Type Discount"
        Me.btnCalculateTypeDiscount.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(268, 293)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(98, 42)
        Me.btnClose.TabIndex = 10
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'frmDiscount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(444, 368)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnCalculateTypeDiscount)
        Me.Controls.Add(Me.btnCalculateVisitDiscount)
        Me.Controls.Add(Me.lblClientTypeDiscountAmount)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblVisitDiscountAmount)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lstSelectClientType)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtNumberofVisits)
        Me.Name = "frmDiscount"
        Me.Text = "Discount"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtNumberofVisits As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lstSelectClientType As ListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lblVisitDiscountAmount As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblClientTypeDiscountAmount As Label
    Friend WithEvents btnCalculateVisitDiscount As Button
    Friend WithEvents btnCalculateTypeDiscount As Button
    Friend WithEvents btnClose As Button
End Class
