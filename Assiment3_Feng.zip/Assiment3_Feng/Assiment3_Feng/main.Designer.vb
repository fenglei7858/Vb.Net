﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnRemoveItem = New System.Windows.Forms.Button()
        Me.lstHairdresserAndServices = New System.Windows.Forms.ListBox()
        Me.lstPrice = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblClientTypeDiscount = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblTotalPrice = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblVisitDiscount = New System.Windows.Forms.Label()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.MnuFileReset = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptions = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptionsHairdresser = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptionsServices = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptionsApplyDiscount = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(12, 367)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(142, 47)
        Me.btnCalculate.TabIndex = 1
        Me.btnCalculate.Text = "Calculate Total Price"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(196, 367)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(135, 47)
        Me.btnReset.TabIndex = 2
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnRemoveItem
        '
        Me.btnRemoveItem.Location = New System.Drawing.Point(376, 367)
        Me.btnRemoveItem.Name = "btnRemoveItem"
        Me.btnRemoveItem.Size = New System.Drawing.Size(129, 47)
        Me.btnRemoveItem.TabIndex = 3
        Me.btnRemoveItem.Text = "Remove Item"
        Me.btnRemoveItem.UseVisualStyleBackColor = True
        '
        'lstHairdresserAndServices
        '
        Me.lstHairdresserAndServices.FormattingEnabled = True
        Me.lstHairdresserAndServices.ItemHeight = 12
        Me.lstHairdresserAndServices.Location = New System.Drawing.Point(161, 64)
        Me.lstHairdresserAndServices.Name = "lstHairdresserAndServices"
        Me.lstHairdresserAndServices.Size = New System.Drawing.Size(194, 268)
        Me.lstHairdresserAndServices.TabIndex = 4
        '
        'lstPrice
        '
        Me.lstPrice.FormattingEnabled = True
        Me.lstPrice.ItemHeight = 12
        Me.lstPrice.Location = New System.Drawing.Point(376, 64)
        Me.lstPrice.Name = "lstPrice"
        Me.lstPrice.Size = New System.Drawing.Size(87, 268)
        Me.lstPrice.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(161, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(149, 12)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Hairdresser and Services"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(376, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 12)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Price"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(490, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 12)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Price"
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.Location = New System.Drawing.Point(494, 90)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(0, 12)
        Me.lblPrice.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(490, 174)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(125, 12)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Client Type Discount"
        '
        'lblClientTypeDiscount
        '
        Me.lblClientTypeDiscount.AutoSize = True
        Me.lblClientTypeDiscount.Location = New System.Drawing.Point(494, 201)
        Me.lblClientTypeDiscount.Name = "lblClientTypeDiscount"
        Me.lblClientTypeDiscount.Size = New System.Drawing.Size(0, 12)
        Me.lblClientTypeDiscount.TabIndex = 11
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(490, 236)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(71, 12)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Total Price"
        '
        'lblTotalPrice
        '
        Me.lblTotalPrice.AutoSize = True
        Me.lblTotalPrice.Location = New System.Drawing.Point(494, 266)
        Me.lblTotalPrice.Name = "lblTotalPrice"
        Me.lblTotalPrice.Size = New System.Drawing.Size(0, 12)
        Me.lblTotalPrice.TabIndex = 13
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(490, 119)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(89, 12)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Visit Discount"
        '
        'lblVisitDiscount
        '
        Me.lblVisitDiscount.AutoSize = True
        Me.lblVisitDiscount.Location = New System.Drawing.Point(494, 145)
        Me.lblVisitDiscount.Name = "lblVisitDiscount"
        Me.lblVisitDiscount.Size = New System.Drawing.Size(0, 12)
        Me.lblVisitDiscount.TabIndex = 15
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MnuFileReset})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(39, 21)
        Me.mnuFile.Text = "File"
        '
        'MnuFileReset
        '
        Me.MnuFileReset.Name = "MnuFileReset"
        Me.MnuFileReset.Size = New System.Drawing.Size(108, 22)
        Me.MnuFileReset.Text = "Reset"
        '
        'mnuOptions
        '
        Me.mnuOptions.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuOptionsHairdresser, Me.mnuOptionsServices, Me.mnuOptionsApplyDiscount})
        Me.mnuOptions.Name = "mnuOptions"
        Me.mnuOptions.Size = New System.Drawing.Size(66, 21)
        Me.mnuOptions.Text = "Options"
        '
        'mnuOptionsHairdresser
        '
        Me.mnuOptionsHairdresser.Name = "mnuOptionsHairdresser"
        Me.mnuOptionsHairdresser.Size = New System.Drawing.Size(169, 22)
        Me.mnuOptionsHairdresser.Text = "Hairdresser"
        '
        'mnuOptionsServices
        '
        Me.mnuOptionsServices.Name = "mnuOptionsServices"
        Me.mnuOptionsServices.Size = New System.Drawing.Size(169, 22)
        Me.mnuOptionsServices.Text = "Services"
        '
        'mnuOptionsApplyDiscount
        '
        Me.mnuOptionsApplyDiscount.Name = "mnuOptionsApplyDiscount"
        Me.mnuOptionsApplyDiscount.Size = New System.Drawing.Size(169, 22)
        Me.mnuOptionsApplyDiscount.Text = "Apply Discounts"
        '
        'mnuHelp
        '
        Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAbout})
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(47, 21)
        Me.mnuHelp.Text = "Help"
        '
        'mnuAbout
        '
        Me.mnuAbout.Name = "mnuAbout"
        Me.mnuAbout.Size = New System.Drawing.Size(111, 22)
        Me.mnuAbout.Text = "About"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuOptions, Me.mnuHelp})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(635, 25)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(635, 460)
        Me.Controls.Add(Me.lblVisitDiscount)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.lblTotalPrice)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lblClientTypeDiscount)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblPrice)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lstPrice)
        Me.Controls.Add(Me.lstHairdresserAndServices)
        Me.Controls.Add(Me.btnRemoveItem)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMain"
        Me.Text = "Main"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnRemoveItem As Button
    Friend WithEvents lstHairdresserAndServices As ListBox
    Friend WithEvents lstPrice As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblPrice As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblClientTypeDiscount As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblTotalPrice As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lblVisitDiscount As Label
    Friend WithEvents mnuFile As ToolStripMenuItem
    Friend WithEvents MnuFileReset As ToolStripMenuItem
    Friend WithEvents mnuOptions As ToolStripMenuItem
    Friend WithEvents mnuOptionsHairdresser As ToolStripMenuItem
    Friend WithEvents mnuOptionsServices As ToolStripMenuItem
    Friend WithEvents mnuOptionsApplyDiscount As ToolStripMenuItem
    Friend WithEvents mnuHelp As ToolStripMenuItem
    Friend WithEvents mnuAbout As ToolStripMenuItem
    Friend WithEvents MenuStrip1 As MenuStrip
End Class
