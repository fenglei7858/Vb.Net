﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmService
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lstSelectaService = New System.Windows.Forms.ListBox()
        Me.btnAddService = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(62, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(101, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Select a Service"
        '
        'lstSelectaService
        '
        Me.lstSelectaService.FormattingEnabled = True
        Me.lstSelectaService.ItemHeight = 12
        Me.lstSelectaService.Location = New System.Drawing.Point(64, 50)
        Me.lstSelectaService.Name = "lstSelectaService"
        Me.lstSelectaService.Size = New System.Drawing.Size(222, 220)
        Me.lstSelectaService.TabIndex = 1
        '
        'btnAddService
        '
        Me.btnAddService.Location = New System.Drawing.Point(50, 286)
        Me.btnAddService.Name = "btnAddService"
        Me.btnAddService.Size = New System.Drawing.Size(99, 41)
        Me.btnAddService.TabIndex = 2
        Me.btnAddService.Text = "Add Service"
        Me.btnAddService.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(210, 286)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(100, 41)
        Me.btnClose.TabIndex = 3
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'frmService
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(390, 361)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnAddService)
        Me.Controls.Add(Me.lstSelectaService)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmService"
        Me.Text = "Service"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents lstSelectaService As ListBox
    Friend WithEvents btnAddService As Button
    Friend WithEvents btnClose As Button
End Class
