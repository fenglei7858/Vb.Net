﻿'Statement of Author ship: I,Lei Feng, 000355541
'                          certify that this material is my original work. 
'                          No other person's work has been used without due acknowledgement.
'
Module Module1

    ' Constants Hairdressers Name
    Public strHairdresser() As Object = {"Jane Samley", "Pat Johnson", "Ron Chambers", "Sue Pallon", "Laurie Renkins"}

    ' Constants Hairdressers Base Prices 
    Public dblHairdresserBasePrices() As Double = {30, 45, 40, 50, 55}

    ' Constants Services Name
    Public strService() As Object = {"Cut, Wash, Blowdry, and Style", "Colour", "Highlight", "Extensions", "Up do", "Wash, Blowdry, and Style"}

    ' Constants Services fees
    Public dblServicesFees() As Decimal = {30, 40, 50, 200, 60, 50}

    ' Constants Client Types
    Public strClientType() As Object = {"Standard Adult", "Child (12 and under)", "Student", "Senior (over 65)"}

    ' Constants Client Types Discount
    Public dblClientTypesDiscount() As Decimal = {0, 0.1, 0.05, 0.15}

    ' Constants Visit Discount
    Public dblVisitDiscount() As Decimal = {0, 0.05, 0.1, 0.15}

    Public dblPrice As Double = 0
    Public strVisitDiscount As String
    Public strTypeDiscount As String

    Public Sub CalculateVisitDiscount(ByVal intNumberOfVisits As Integer)

        strVisitDiscount = ""
        CalculatePrice() ' Calculate the total price from the price list

        ' Determine the discount based on the list
        If intNumberOfVisits >= 1 And intNumberOfVisits <= 3 Then
            strVisitDiscount = (dblPrice * dblVisitDiscount(0)).ToString("c")
        ElseIf intNumberOfVisits >= 4 And intNumberOfVisits <= 8 Then
            strVisitDiscount = (dblPrice * dblVisitDiscount(1)).ToString("c")
        ElseIf intNumberOfVisits >= 9 And intNumberOfVisits <= 13 Then
            strVisitDiscount = (dblPrice * dblVisitDiscount(2)).ToString("c")
        ElseIf intNumberOfVisits >= 14 Then
            strVisitDiscount = (dblPrice * dblVisitDiscount(3)).ToString("c")
        End If

    End Sub

    Public Sub DeterminTypeDiscount(ByVal intIndex As Integer)

        strTypeDiscount = ""
        ' Calculate the total price from the price list
        CalculatePrice()
        ' Determine the discount based on the number of visits.
        If intIndex = 0 Then
            strTypeDiscount = (dblPrice * dblClientTypesDiscount(0)).ToString("c")
        ElseIf intIndex = 1 Then
            strTypeDiscount = (dblPrice * dblClientTypesDiscount(1)).ToString("c")
        ElseIf intIndex = 2 Then
            strTypeDiscount = (dblPrice * dblClientTypesDiscount(2)).ToString("c")
        ElseIf intIndex = 3 Then
            strTypeDiscount = (dblPrice * dblClientTypesDiscount(3)).ToString("c")
        End If

    End Sub

    Public Sub LoadTypeValues(ByVal array As Array, ByVal control As ListBox)
        'Load all value in the array to the ListBox 
        For Each strTypeValues As String In array
            control.Items.Add(strTypeValues)
        Next
    End Sub

    ' Calculate the total price
    Public Sub CalculatePrice()
        dblPrice = 0
        For intIndex = frmMain.lstPrice.TopIndex To frmMain.lstPrice.Items.Count - 1
            dblPrice += frmMain.lstPrice.Items.Item(intIndex)
        Next
    End Sub
End Module
