﻿'Statement of Author ship: I,Lei Feng, 000355541
'                          certify that this material is my original work. 
'                          No other person's work has been used without due acknowledgement.
'
Public Class frmDiscount
    Private Sub btnCalculateVisitDiscount_Click(sender As Object, e As EventArgs) Handles btnCalculateVisitDiscount.Click
        ' Number of visits
        Dim intVisits As Integer
        ' Error Message
        Dim strErrorMessage As String = ""
        ' set a boolean flag
        Dim blnFlag As Boolean = True

        ' Get the number of Visits.
        Try
            intVisits = CInt(txtNumberofVisits.Text)
            ' check if there are selections, then add it to the list
            If intVisits Mod 1 <> 0 Then
                ' show error message if input is not an integer
                strErrorMessage += " Error! You must enter an integer." & vbCrLf
                blnFlag = False
            End If

            If intVisits <= 0 Then
                ' Error: value entered for Visits is less than zero.
                strErrorMessage += " Error! You must enter at least 1 visit."
                blnFlag = False
            End If
        Catch EX As Exception
            strErrorMessage += " Error! You must enter at least 1 visit."
            blnFlag = False
        End Try
        If blnFlag = True Then
            'call sub from module 1
            CalculateVisitDiscount(intVisits)
            lblVisitDiscountAmount.Text = strVisitDiscount
        Else
            'show error message
            MessageBox.Show(strErrorMessage)
        End If
        'if user used discount form and selected visit number discount, then show it on main form
        If lblVisitDiscountAmount.Text <> "" Then
            frmMain.lblVisitDiscount.Text = lblVisitDiscountAmount.Text
        End If


    End Sub

    Private Sub btnCalculateTypeDiscount_Click(sender As Object, e As EventArgs) Handles btnCalculateTypeDiscount.Click
        'call sub from module 1
        DeterminTypeDiscount(lstSelectClientType.SelectedIndex)
        lblClientTypeDiscountAmount.Text = strTypeDiscount
        'if user used discount form and selected visit type discount, then show it on main form
        If lblClientTypeDiscountAmount.Text <> "" Then
            frmMain.lblClientTypeDiscount.Text = lblClientTypeDiscountAmount.Text
        End If

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'close the from
        Me.Close()
    End Sub

    Private Sub frmDiscount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Load discount values by module1
        LoadTypeValues(Module1.strClientType, lstSelectClientType)
    End Sub
End Class