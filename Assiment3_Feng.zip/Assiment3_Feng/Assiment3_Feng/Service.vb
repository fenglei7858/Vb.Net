﻿'Statement of Author ship: I,Lei Feng, 000355541
'                          certify that this material is my original work. 
'                          No other person's work has been used without due acknowledgement.

Public Class frmService

    Private Sub btnAddService_Click(sender As Object, e As EventArgs) Handles btnAddService.Click
        ' check if there are selections, then add it to the list
        If lstSelectaService.SelectedIndex <> -1 Then
            frmMain.lstHairdresserAndServices.Items.Add(lstSelectaService.SelectedItem)
            AddServicePrice()
            Me.Close()
        End If

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'closr form
        Me.Close()
    End Sub

    Private Sub frmService_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Load service values by module1
        LoadTypeValues(Module1.strService, lstSelectaService)
    End Sub

    Private Sub AddServicePrice()
        ' Add services base rate to the list
        Select Case lstSelectaService.SelectedIndex
            Case 0
                frmMain.lstPrice.Items.Add(Module1.dblServicesFees(0).ToString("c"))
            Case 1
                frmMain.lstPrice.Items.Add(Module1.dblServicesFees(1).ToString("c"))
            Case 2
                frmMain.lstPrice.Items.Add(Module1.dblServicesFees(2).ToString("c"))
            Case 3
                frmMain.lstPrice.Items.Add(Module1.dblServicesFees(3).ToString("c"))
            Case 4
                frmMain.lstPrice.Items.Add(Module1.dblServicesFees(4).ToString("c"))
            Case 5
                frmMain.lstPrice.Items.Add(Module1.dblServicesFees(5).ToString("c"))
        End Select
    End Sub
End Class