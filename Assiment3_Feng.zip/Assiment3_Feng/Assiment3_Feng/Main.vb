﻿'Statement of Author ship: I,Lei Feng, 000355541
'                          certify that this material is my original work. 
'                          No other person's work has been used without due acknowledgement.

Public Class frmMain
    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Try
            CalculatePrice()
            lblPrice.Text = Module1.dblPrice.ToString("c")
            ' lblTotalPrice.Text = (lblPrice.Text - lblVisitDiscount.Text - lblClientTypeDiscount.Text).ToString("c") 'Calculate the totatl price 
            lblTotalPrice.Text = (CDbl(lblPrice.Text) - CDbl(lblVisitDiscount.Text) - CDbl(lblClientTypeDiscount.Text)).ToString("c")
        Catch EX As Exception
            MessageBox.Show("You should select hairdresser, services, and visit numbers. See options.")
        End Try
    End Sub

    Private Sub mnuFile_Click(sender As Object, e As EventArgs) Handles mnuFile.Click

    End Sub

    Private Sub MnuFileReset_Click(sender As Object, e As EventArgs) Handles MnuFileReset.Click
        Reset()
    End Sub

    Private Sub mnuOptionsHairdresser_Click(sender As Object, e As EventArgs) Handles mnuOptionsHairdresser.Click
        Dim frmHairdresser As New frmHairdresser ' create a new object for Hairdresser form
        frmHairdresser.ShowDialog() 'show the Hairdresser form
    End Sub

    Private Sub mnuOptionsServices_Click(sender As Object, e As EventArgs) Handles mnuOptionsServices.Click
        Dim frmService As New frmService ' create a new object for Service form
        frmService.ShowDialog() 'show the service form
    End Sub

    Private Sub mnuOptionsAppleDicsount_Click(sender As Object, e As EventArgs) Handles mnuOptionsApplyDiscount.Click
        Dim frmApplyDiscount As New frmDiscount ' create a new object for discount form
        frmDiscount.ShowDialog() 'show the service form
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    ' create a reset sub
    Private Sub Reset()

        'Clear two lists
        lstHairdresserAndServices.Items.Clear()
        lstPrice.Items.Clear()
        frmDiscount.lstSelectClientType.Items.Clear()
        'Clear 4 lables 
        lblPrice.Text = ""
        lblVisitDiscount.Text = ""
        lblClientTypeDiscount.Text = ""
        lblTotalPrice.Text = ""

    End Sub

    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click
        MessageBox.Show("Sorry! There are no more information")
    End Sub

    Private Sub btnRemoveItem_Click(sender As Object, e As EventArgs) Handles btnRemoveItem.Click
        ' check if there are selections, then remove it by index and clear 4 lables
        If lstPrice.SelectedIndex <> -1 Then
            lstHairdresserAndServices.Items.RemoveAt(lstPrice.SelectedIndex)
            lstPrice.Items.RemoveAt(lstPrice.SelectedIndex)

            'Clear 4 lables
            lblPrice.Text = ""
            lblClientTypeDiscount.Text = ""
            lblTotalPrice.Text = ""
            lblVisitDiscount.Text = ""

        End If
        ' check if there are selections, then remove it by index and clear 4 lables
        If lstHairdresserAndServices.SelectedIndex <> -1 Then
            lstPrice.Items.RemoveAt(lstHairdresserAndServices.SelectedIndex)
            lstHairdresserAndServices.Items.RemoveAt(lstHairdresserAndServices.SelectedIndex)

            'Clear 4 lables
            lblPrice.Text = ""
            lblClientTypeDiscount.Text = ""
            lblTotalPrice.Text = ""
            lblVisitDiscount.Text = ""
        End If
        Try
            CalculatePrice()
            lblPrice.Text = Module1.dblPrice.ToString("c")

        Catch EX As Exception
            MessageBox.Show(EX.ToString)
        End Try
    End Sub

    Private Sub lblPrice_Click(sender As Object, e As EventArgs) Handles lblPrice.Click

    End Sub
End Class
