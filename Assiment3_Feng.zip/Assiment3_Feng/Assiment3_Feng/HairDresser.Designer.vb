﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHairdresser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnAddHairdresser = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lstHairdresser = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(94, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(125, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Select a Hairdresser"
        '
        'btnAddHairdresser
        '
        Me.btnAddHairdresser.Location = New System.Drawing.Point(64, 285)
        Me.btnAddHairdresser.Name = "btnAddHairdresser"
        Me.btnAddHairdresser.Size = New System.Drawing.Size(105, 44)
        Me.btnAddHairdresser.TabIndex = 1
        Me.btnAddHairdresser.Text = "Add Hairdresser"
        Me.btnAddHairdresser.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(220, 286)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(106, 43)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lstHairdresser
        '
        Me.lstHairdresser.FormattingEnabled = True
        Me.lstHairdresser.ItemHeight = 12
        Me.lstHairdresser.Location = New System.Drawing.Point(96, 60)
        Me.lstHairdresser.Name = "lstHairdresser"
        Me.lstHairdresser.Size = New System.Drawing.Size(217, 196)
        Me.lstHairdresser.TabIndex = 3
        '
        'frmHairdresser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(438, 351)
        Me.Controls.Add(Me.lstHairdresser)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnAddHairdresser)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmHairdresser"
        Me.Text = "HairDresser"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents btnAddHairdresser As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents lstHairdresser As ListBox
End Class
