﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.asdasd = New System.Windows.Forms.TextBox()
        Me.cmbSelect = New System.Windows.Forms.ComboBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.lstSelectAService = New System.Windows.Forms.ListBox()
        Me.lstHairdresserAndService = New System.Windows.Forms.ListBox()
        Me.lstPrice = New System.Windows.Forms.ListBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.txtTotalPrice = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'asdasd
        '
        Me.asdasd.AllowDrop = True
        Me.asdasd.BackColor = System.Drawing.SystemColors.Menu
        Me.asdasd.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.asdasd.Location = New System.Drawing.Point(26, 13)
        Me.asdasd.Name = "asdasd"
        Me.asdasd.Size = New System.Drawing.Size(151, 14)
        Me.asdasd.TabIndex = 0
        Me.asdasd.Text = "Select a HairDresser"
        '
        'cmbSelect
        '
        Me.cmbSelect.FormattingEnabled = True
        Me.cmbSelect.Items.AddRange(New Object() {"Jane Samley", "Pat Johnson", "Ron Chambers", "Sue Pallon", "Laura Renkins"})
        Me.cmbSelect.Location = New System.Drawing.Point(26, 34)
        Me.cmbSelect.Name = "cmbSelect"
        Me.cmbSelect.Size = New System.Drawing.Size(217, 20)
        Me.cmbSelect.TabIndex = 1
        Me.cmbSelect.Text = "By Using Down Arrow"
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Location = New System.Drawing.Point(262, 13)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(150, 14)
        Me.TextBox1.TabIndex = 2
        Me.TextBox1.Text = "Select a Service"
        '
        'lstSelectAService
        '
        Me.lstSelectAService.FormattingEnabled = True
        Me.lstSelectAService.ItemHeight = 12
        Me.lstSelectAService.Items.AddRange(New Object() {"Cut, Wash, Blowdry and Style", "Colour", "Highlight", "Extensions", "Up Do", "Wash, Blowdry and Style"})
        Me.lstSelectAService.Location = New System.Drawing.Point(262, 33)
        Me.lstSelectAService.Name = "lstSelectAService"
        Me.lstSelectAService.Size = New System.Drawing.Size(231, 232)
        Me.lstSelectAService.TabIndex = 3
        '
        'lstHairdresserAndService
        '
        Me.lstHairdresserAndService.FormattingEnabled = True
        Me.lstHairdresserAndService.ItemHeight = 12
        Me.lstHairdresserAndService.Location = New System.Drawing.Point(517, 34)
        Me.lstHairdresserAndService.Name = "lstHairdresserAndService"
        Me.lstHairdresserAndService.Size = New System.Drawing.Size(170, 232)
        Me.lstHairdresserAndService.TabIndex = 4
        '
        'lstPrice
        '
        Me.lstPrice.FormattingEnabled = True
        Me.lstPrice.ItemHeight = 12
        Me.lstPrice.Location = New System.Drawing.Point(712, 34)
        Me.lstPrice.Name = "lstPrice"
        Me.lstPrice.Size = New System.Drawing.Size(120, 232)
        Me.lstPrice.TabIndex = 5
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Location = New System.Drawing.Point(517, 6)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(170, 14)
        Me.TextBox2.TabIndex = 6
        Me.TextBox2.Text = "Hairdresser and Service"
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox3.Location = New System.Drawing.Point(712, 6)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 14)
        Me.TextBox3.TabIndex = 7
        Me.TextBox3.Text = "Price"
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox4.Location = New System.Drawing.Point(94, 315)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 14)
        Me.TextBox4.TabIndex = 8
        Me.TextBox4.Text = "Total Price"
        '
        'txtTotalPrice
        '
        Me.txtTotalPrice.Location = New System.Drawing.Point(312, 308)
        Me.txtTotalPrice.Name = "txtTotalPrice"
        Me.txtTotalPrice.Size = New System.Drawing.Size(100, 21)
        Me.txtTotalPrice.TabIndex = 9
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(50, 373)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(165, 46)
        Me.btnAdd.TabIndex = 10
        Me.btnAdd.Text = "Add Service"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(290, 373)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(165, 46)
        Me.btnCalculate.TabIndex = 11
        Me.btnCalculate.Text = "Calculate Total Price"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(504, 373)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(165, 46)
        Me.btnReset.TabIndex = 12
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(700, 373)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(165, 46)
        Me.btnExit.TabIndex = 13
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(868, 472)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.txtTotalPrice)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.lstPrice)
        Me.Controls.Add(Me.lstHairdresserAndService)
        Me.Controls.Add(Me.lstSelectAService)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.cmbSelect)
        Me.Controls.Add(Me.asdasd)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents asdasd As TextBox
    Friend WithEvents cmbSelect As ComboBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents lstSelectAService As ListBox
    Friend WithEvents lstHairdresserAndService As ListBox
    Friend WithEvents lstPrice As ListBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents txtTotalPrice As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
End Class
