﻿Public Class Form1
    'Statement of Author ship: I, Lei Feng, 000355541 
    '                          certify that this material is my original work. 
    '                          No other person's work has been used without due acknowledgement.
    '
    'Program description: 
    '                1. Users choose a hairdresser from the combo box
    '                2. Users choose Services from the the second list box
    '                3. When user first time click the "Add Service" buttom, the selected hairdresser and Service
    '                   will be present in the second list box. The corresponding price will be in the third list box
    '                4. When user click the "Add Service" buttom again, only the Service and it's corresponding price will be in list boxes
    '                5. "Calculate" bottom is used for Calculating the total price
    '                6. "Reset" bottom clears both the description and price list boxes, clears selection from service list box, 
    '                   clears total price display And takes care Of any other needed reset processes

    ' Constants for base Rate
    Const decJANE_RATE As Decimal = 30D
    Const decPAT_RATE As Decimal = 45D
    Const decRON_RATE As Decimal = 40D
    Const decSUE_RATE As Decimal = 50D
    Const decLAURA_RATE As Decimal = 55D

    ' Constants for Services  fees
    Const decCUT_WASH_BLOWDRY_STYLE_FEE As Decimal = 30D
    Const decCOLOUR_FEE As Decimal = 40D
    Const decHIGHLIGHTS_FEE As Decimal = 50D
    Const decEXTENSIONS_FEE As Decimal = 200D
    Const decUP_DO_FEE As Decimal = 60D
    Const decWASH_BLOWDRY_STYLE_FEE As Decimal = 50D

    Dim blnStart As Boolean = True       ' The first time to add a hairdresser
    Dim decTotalPrice As Decimal = 0     ' Total price



    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If blnStart = True Then
            lstHairdresserAndService.Items.Add(cmbSelect.SelectedItem) ' add selected hairdresser from Combobox to Hairdresser and Service List
            lstHairdresserAndService.Items.Add(lstSelectAService.SelectedItem) ' add selected service from Service List to Hairdresser and Service List
            BasePrice() 'call BasePrice
            ServicePrice() ' call ServicePrice         
        Else
            lstHairdresserAndService.Items.Add(lstSelectAService.SelectedItem)
            ServicePrice()
        End If
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'calculate all items listed in the Price List
        For intIndex = lstPrice.TopIndex To lstPrice.Items.Count - 1
            decTotalPrice += lstPrice.Items.Item(intIndex)
        Next
        txtTotalPrice.Text = decTotalPrice.ToString("c") ' Diaplay the total price
        decTotalPrice = 0 ' Reset the total price
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ' reset everything
        cmbSelect.SelectedIndex = -1 ' reset hairdresser combobox 
        cmbSelect.Text = "By using Down Arrow" 'reset hairdresser combox text
        lstSelectAService.ClearSelected() ' reset service
        lstHairdresserAndService.Items.Clear() ' reset hairdresser and service that are selected list
        lstPrice.Items.Clear() 'reset price list
        txtTotalPrice.Clear() 'reset total price


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'exit
        Me.Close() 

    End Sub

    Private Sub BasePrice()
        ' using case to add base hairdresser price to the price list
        Select Case cmbSelect.SelectedIndex
            Case 0
                lstPrice.Items.Add(decJANE_RATE.ToString("c"))
            Case 1
                lstPrice.Items.Add(decPAT_RATE.ToString("c"))
            Case 2
                lstPrice.Items.Add(decRON_RATE.ToString("c"))
            Case 2
                lstPrice.Items.Add(decSUE_RATE.ToString("c"))
            Case 4
                lstPrice.Items.Add(decLAURA_RATE.ToString("c"))
        End Select

    End Sub

    Private Sub ServicePrice()
        ' using case to add service price to the price list
        Select Case cmbSelect.SelectedIndex
            Case 0
                lstPrice.Items.Add(decCUT_WASH_BLOWDRY_STYLE_FEE.ToString("c"))
            Case 1
                lstPrice.Items.Add(decCOLOUR_FEE.ToString("c"))
            Case 2
                lstPrice.Items.Add(decHIGHLIGHTS_FEE.ToString("c"))
            Case 3
                lstPrice.Items.Add(decEXTENSIONS_FEE.ToString("c"))
            Case 4
                lstPrice.Items.Add(decUP_DO_FEE.ToString("c"))
            Case 5
                lstPrice.Items.Add(decWASH_BLOWDRY_STYLE_FEE.ToString("c"))
        End Select
    End Sub
End Class
